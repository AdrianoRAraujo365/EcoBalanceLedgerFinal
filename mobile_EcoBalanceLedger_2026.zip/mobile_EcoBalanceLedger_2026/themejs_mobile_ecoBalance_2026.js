##Themejs EcoBalanceLedger mobile
// Design tokens — espelham o tema escuro do index.html (Tailwind custom)
export const colors = {
  bg: "#0f172a",
  card: "#1e293b",
  border: "rgba(255,255,255,0.1)",
  primary: "#10b981",   // emerald-500
  primaryDark: "#059669",
  secondary: "#0ea5e9", // sky-500
  accent: "#8b5cf6",    // violet-500
  danger: "#ef4444",
  warning: "#f59e0b",
  text: "#f8fafc",
  muted: "#9ca3af",
};

export const spacing = (n) => n * 4;